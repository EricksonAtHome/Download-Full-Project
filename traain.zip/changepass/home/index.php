<!DOCTYPE html>
<html>
<head>
  
   <meta http-equiv="refresh"
   content="0; url=../../home">
</head>

</html>