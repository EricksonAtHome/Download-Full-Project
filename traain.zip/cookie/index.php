<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
   
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/Highlight-Clean.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
    <div class="highlight-clean">
        <div class="container">
            <div class="intro">
                <h2 class="text-center"><img src="assets/img/cookie.svg"></h2>
                <p class="text-center"><img src="assets/img/logo.svg"></p>
            </div>
        </div>
        <div class="container">
            <div class="intro">
                <h2 class="text-center"><img src="assets/img/text.svg"></h2>
				
				<center>
					

					<button onclick="alertCookieValue()"><img src="assets/img/weten.svg"></button>

					
					
            </center>
				
				
				<br>
				
				              

				
               <a href="back.php"> <p class="text-center"><img src="assets/img/prima.svg"></p></a>
				
				
            </div>
        </div>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
	    <script src="callback.js"></script>


</body>

</html>