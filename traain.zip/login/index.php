<?php

include '../app/link.php';

include '../app/nav.php';

include '../app/banner.php';
include '../login.php';

include '../app/footer.php';

?>