<body style="background: linear-gradient(rgb(238,244,247), rgb(238,244,247));"><br><br>
<div>
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="intro">
                    <h2>Koop uw treinkaartjes<a href=".../../info" class="btn btn-info btn-circle ml-1" role="button"><i class="fas fa-info-circle text-white"></i>

                    </a><br /></h2>
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="text-primary m-0 font-weight-bold">Wij verkopen overal <strong>treinkaartjes</strong>, waar u ook bent, wij hebben het altijd.<br /></h6>
                        </div>
                        <div class="card-body">
                            <p class="m-0">(koop.je.koop uw treinkaartjes.ini)</p>
                        </div>
                    </div><a class="btn btn-primary" role="button" href="store">Traain winkel</a>&nbsp;&nbsp;<a class="btn btn-primary" role="button" href="miniature">Traain Miniatuur (TM-winkel)</a></div>
            </div>
            <div class="col-sm-4">
                <div class="d-none d-md-block phone-mockup"><img class="img-fluid device" src="assets/img/713309.svg" />
                    <div class="screen"></div>
                </div>
            </div>
        </div>
    </div>