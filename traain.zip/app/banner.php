
<body>
    <div class="highlight-clean" style="background: url(&quot;../../assets/login-background1.png&quot;);">
        <div class="container">
            <div class="intro">
                <h2 class="text-center"><img src="../../assets/img/trnblack.svg"></h2>
                <p class="text-center"><strong>Wij verkopen overal&nbsp;treinkaartjes, waar u ook bent, wij hebben het altijd.</strong><br></p>
            </div>
        </div>
    </div>
