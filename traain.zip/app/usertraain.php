<body>
    <div class="text-center profile-card" style="margin:15px;background-color:#ffffff;">
        <div class="profile-card-img" style="height: 150px;background: url(&quot;../../assets/img/jjk6cnsbmu8yvbce_1591791559.webp&quot;) center / cover;"></div>
        <div><img class="img-thumbnail" style="margin-top:-70px;" src="../../assets/img/trn.png" height="150px">
            <h3>Traain</h3>
            <p style="padding:20px;padding-bottom:0;padding-top:5px;">()</p>
        </div>
    </div>
    <ul class="list-group">
        <li class="list-group-item">
            <div class="media">
                <div></div>
                <div class="media-body">
                    <div class="media" style="overflow:visible;">
                        <div><img class="mr-3" style="width: 25px; height:25px;" src="../../assets/img/trn.png"></div>
                        <div class="media-body" style="overflow:visible;">
                            <div class="row">
                                <div class="col-md-12">
                                    <p><a href="#">Traain</a>&nbsp;&nbsp;<a href="#">()</a>&nbsp;<br>
<small class="text-muted">erteterterter</small></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </li>
        <li class="list-group-item">
            <div class="media">
                <div></div>
                <div class="media-body">
                    <div class="media" style="overflow:visible;">
                        <div><img class="mr-3" style="width: 25px; height:25px;" src="../../assets/img/trn.png"></div>
                        <div class="media-body" style="overflow:visible;">
                            <div class="row">
                                <div class="col-md-12">
                                    <p><a href="#">Traain</a>&nbsp;&nbsp;<a href="#">()</a>&nbsp;<br>
<small class="text-muted">erteterterter</small></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </li>
        <li class="list-group-item">
            <div class="media">
                <div></div>
                <div class="media-body">
                    <div class="media" style="overflow:visible;">
                        <div><img class="mr-3" style="width: 25px; height:25px;" src="../../assets/img/trn.png"></div>
                        <div class="media-body" style="overflow:visible;">
                            <div class="row">
                                <div class="col-md-12">
                                    <p><a href="#">Traain</a>&nbsp;&nbsp;<a href="#">()</a>&nbsp;<br>
<small class="text-muted">erteterterter</small></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </li>
    </ul>