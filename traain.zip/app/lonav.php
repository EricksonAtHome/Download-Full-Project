<nav class="navbar navbar-light navbar-expand-md navigation-clean">
    <div class="container"><a class="navbar-brand" href="../../home"><img src="../../assets/img/trnblack.svg"></a>
		
		
   
            <ul class="nav navbar-nav ml-auto">
                <li class="nav-item"></li>
                <li class="nav-item"><a class="nav-link" href="../../changepass">Verander wachtwoord<br /></a></li>
                <li class="nav-item"><a class="nav-link" href="../../profiel ">Profiel</a></li>
                <li class="nav-item"><a class="nav-link" href="../../application/logout.php?logout=true">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>