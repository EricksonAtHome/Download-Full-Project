 <div class="container">
        <div class="intro"></div>
    </div>
</div><div class="footer-basic" style="background: linear-gradient(rgb(238,244,247), rgb(238,244,247));">
    <footer>
        <ul class="list-inline">
            <li class="list-inline-item"><a href="../../../">Terug</a></li>
            <li class="list-inline-item"><a href="../../services">Diensten</a></li>
            <li class="list-inline-item"><a href="../../about">Over Traain</a></li>
            <li class="list-inline-item"><a href="../../tpp">Voorwaarden / Privacybeleid</a></li>
            <li class="list-inline-item"><a ><div id="google_translate_element"></div>
</a></li>
        </ul>
        <p class="copyright">Traain Bedrijf  © van OnlineThuis Het Project is op
<a href="https://github.com/Traainbusiness"><img src="http://pngimg.com/uploads/github/github_PNG15.png" width="100"></a></p>
    </footer>
</div>





<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

<script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
}
</script>