<?php

include '../../app/link.php';

include '../../app/nav.php';

include '../../app/usertraain.php';

include '../../app/footer.php';

?>

